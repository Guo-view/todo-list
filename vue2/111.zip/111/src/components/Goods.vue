<template>
    <div>goods</div>
</template>